import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-layout-component',
  templateUrl: './main-layout-component.component.html',
  styleUrls: ['./main-layout-component.component.css']
})
export class MainLayoutComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
